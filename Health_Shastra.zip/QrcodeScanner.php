<?php
include 'db_con.php';


$parameterValue = $_GET['parameter'];



$select_query = "SELECT name,surname,age FROM `Patient_Info` WHERE number='$parameterValue'";

$result = mysqli_query($conn, $select_query);

if (mysqli_num_rows($result) != 0) {
    while ($row = mysqli_fetch_array($result)) {
        $data[] = $row;
    }
    // json_encode($data);
    
    $dataArray = json_decode(json_encode($data), true);

// Check if data is not empty
if (!empty($dataArray)) {
    echo '<table border="1">';
    // Table header
    echo '<tr>';
    foreach ($dataArray[0] as $key => $value) {
        echo '<th>' . htmlspecialchars($key) . '</th>';
    }
    echo '</tr>';

    // Table data
    foreach ($dataArray as $row) {
        echo '<tr>';
        foreach ($row as $key => $value) {
            echo '<td>' . htmlspecialchars($value) . '</td>';
        }
        echo '</tr>';
    }
    echo '</table>';
} else {
    echo 'No data available';
}

}
?>
