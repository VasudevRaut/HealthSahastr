<?php

include 'db_con.php';

$emp_contact = $_POST["emp_contact"];
$emp_pass = $_POST['emp_pass'];


// $emp_contact = '0528713674';
// $emp_pass = '123';

$select_query = "SELECT * FROM `Patient_Info` WHERE number='$emp_contact'";

$result = mysqli_query($conn, $select_query);


if(mysqli_num_rows($result) != 0)
{
    while($row = mysqli_fetch_array($result))
    {
    
        if($row['number'] == $emp_contact && $row['pass'] == $emp_pass)
        {
            
            $data = "success";
            // $data = $row['emp_gender'].",1";
            echo json_encode($data);
            break;
        }
        else  
        {
            $data = "failed";
            echo json_encode($data);
            break;
        }
    }
}
else
{
    $data1 = "passwordNot";
    echo json_encode($data1);
    
}



?>


