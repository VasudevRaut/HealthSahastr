<?php
include 'db_con.php';

$select_query = "SELECT * FROM `Doctor_Info` WHERE active_status='on'";

$result = mysqli_query($conn, $select_query);

if (mysqli_num_rows($result) != 0) {
    $data = array();
    while ($row = mysqli_fetch_array($result)) {
        $data[] = $row;
    }
    echo json_encode($data);
} else {
    $data1 = "passwordNot";
    echo json_encode($data1);
}
?>
