<?php

include 'db_con.php';

$fname = $_POST['fname'];
$lname = $_POST['lname'];
$mail = $_POST['mail'];
$contact = $_POST['contact'];
$password = $_POST['password'];
$age = $_POST['age'];
 


// $fname = "Rahul";
// $lname = "Shinde";
// $mail = "Shinderahul.9921@gmail.com";
// $contact = "9960210230";
// $password = "123";
// $age = "20";
 

$select_query = "SELECT * FROM `Patient_Info` WHERE number = '$contact'";

$result = mysqli_query($conn, $select_query);

if ($result) {
    $rows_returned = mysqli_num_rows($result);

    if ($rows_returned > 0) {
        $response['message'] = "already_present";
        echo json_encode($response);
    } else {
        $insert_query = "INSERT INTO `Patient_Info`(`name`, `surname`, `number`, `email`, `pass`, `age`)
        VALUES ('$fname','$lname','$contact','$mail','$password','$age')";

        $isDataUpdated = mysqli_query($conn, $insert_query);

        if ($isDataUpdated) {
            $response['message'] = "success";
            echo json_encode($response);
        } else {
            $response['message'] = "failed to store";
            echo json_encode($response);
        }
    }
}

 
?>