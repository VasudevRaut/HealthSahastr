<?php

include 'db_con.php';
$manager_mobile = $_POST['manager_mobile'];
$device_token = $_POST['device_token'];

 
$select_query = "SELECT number FROM `Patient_Info` WHERE number = '$manager_mobile'";

$result = mysqli_query($conn, $select_query);


if($result)
{

    $rows_returned = mysqli_num_rows($result);
    
    if($rows_returned > 0)
    {
     
    
       $insert_query ="UPDATE `Patient_Info` SET `token` = '$device_token' WHERE `number` = '$manager_mobile'";

        
        $isDataUpdated = mysqli_query($conn, $insert_query);
        
        if($isDataUpdated)
        {
            $response = "success";
            echo json_encode($response);
        }
        else
        {
            $response = "failed to store";
            echo json_encode($response);
        }       
      
    }
    else
    {
        //insert query fire here

        
        
            $insert_query ="INSERT INTO `Patient_Info` (`token`) VALUES ($device_token')";
        
        $isDataUpdated = mysqli_query($conn, $insert_query);
        
        if($isDataUpdated)
        {
            $respons = "success";
            echo json_encode($response);
        }
        else
        {
            $response= "failed to store1";
            echo json_encode($response);
        }       
    }
}
 
?>