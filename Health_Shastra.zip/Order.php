<?php

include 'db_con.php';

$mobile = $_POST['mobile'];


 


date_default_timezone_set('Asia/Kolkata');

// Get the current date
$currentDate = date('Y-m-d');

// Get the current time
$currentTime = date('H:i:s');
 


        $insert_query = "INSERT INTO `Appointment`(`patient_number`, `doctor_number`, `date`, `time`, `payment_status`, `appointment_status`)
        VALUES ('$mobile','555555','$currentDate','$currentTime','completed','upcoming')";

        $isDataUpdated = mysqli_query($conn, $insert_query);

        if ($isDataUpdated) {
            $response['message'] = "success";
            echo json_encode($response);
        } else {
            $response['message'] = "failed to store";
            echo json_encode($response);
        }

 
?>