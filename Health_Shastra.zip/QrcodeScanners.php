<?php

include 'db_con.php';
$parameterValue = $_GET['parameter'];



$all_leads = "SELECT name,surname,age FROM `Patient_Info` WHERE number='$parameterValue'";

$result = mysqli_query($conn, $all_leads);
    

while($row = mysqli_fetch_assoc($result))   
{
    
    
    $all_leads1 = "SELECT doctor_number,prescription,date,	time FROM `Appointment` WHERE patient_number='$parameterValue'";

    $result1 = mysqli_query($conn, $all_leads1);
    
    while($row1 = mysqli_fetch_assoc($result1))   
    {
        $datas1 = $row1;
        
    }
    
    
    
   $datas = $row;
   
   
   
   
   $datas[] = array_merge($datas1, $datas);
 
    
    
    
    
    
    
}

// echo;

$dataArray = json_decode( json_encode($datas), true);

// Check if data is not empty
if (!empty($dataArray)) {
    echo '<table border="1">';
    // Table header
    echo '<tr>';
    foreach ($dataArray[0] as $key => $value) {
        echo '<th>' . htmlspecialchars($key) . '</th>';
    }
    echo '</tr>';

    // Table data
    foreach ($dataArray as $row) {
        echo '<tr>';
        foreach ($row as $key => $value) {
            echo '<td>' . htmlspecialchars($value) . '</td>';
        }
        echo '</tr>';
    }
    echo '</table>';
} else {
    echo 'No data available';
}



$all_leads = "SELECT doctor_number,date,time,prescription FROM `Appointment` WHERE number='$parameterValue'";

$result = mysqli_query($conn, $all_leads);
    

while($row = mysqli_fetch_assoc($result))   
{
    
    
    // $dn = $row['doctor_number'];
    
    
    
    
   $datas1[] = $row;
 
    
    
    
    
    
    
}

$dataArray1 = json_decode( json_encode($datas1), true);

// Check if data is not empty
if (!empty($dataArray1)) {
    echo '<table border="1">';
    // Table header
    echo '<tr>';
    foreach ($dataArray[0] as $key => $value) {
        echo '<th>' . htmlspecialchars($key) . '</th>';
    }
    echo '</tr>';

    // Table data
    foreach ($dataArray as $row) {
        echo '<tr>';
        foreach ($row as $key => $value) {
            echo '<td>' . htmlspecialchars($value) . '</td>';
        }
        echo '</tr>';
    }
    echo '</table>';
} else {
    echo 'No data available';
}











?>