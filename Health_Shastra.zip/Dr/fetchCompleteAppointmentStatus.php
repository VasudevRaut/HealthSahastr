<?php

include 'db_con.php';
$mobile = $_POST['number'];
// $mobile = '123456';


$all_leads = "SELECT * FROM `Appointment` WHERE doctor_number='$mobile' AND appointment_status ='completed'";

$result = mysqli_query($conn, $all_leads);
    

while($row = mysqli_fetch_assoc($result))   
{
    
    $pationt_num = $row['patient_number'];
    
    $all_leads1 = "SELECT * FROM `Patient_Info` WHERE number='$pationt_num'";

    $result1 = mysqli_query($conn, $all_leads1);
    
      $array1 = array(
    "date" => $row['date'],
    "time" => $row['time']
    );
    while($row1 = mysqli_fetch_assoc($result1))
    {
        
      
     $data = $row1;
    
    
    
   
    
       

    
   
    




        
        
        
    }
    
    // $mergedArray 
    
    
        $datas[] = array_merge($array1, $data);
 
    
    
    
    
    
    
}

echo json_encode($datas);

?>