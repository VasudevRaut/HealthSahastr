<?php

include 'db_con.php';
$pnumber = $_POST['pnumber'];




// $pnumber = "7387579912";
// $dnumber = "123456";

// $appid = "1";
$status = $_POST['status'];
// $priciption = "Vasudevvvvvvvvvvvvvvvvvvvvvvvvvvvv";


        
     
     
     
     
       $insert_query ="UPDATE `Doctor_Info` SET `active_status` = '$status' WHERE `number` = '$pnumber'";

        
        $isDataUpdated = mysqli_query($conn, $insert_query);
        
        if($isDataUpdated)
        {
            $response = "success";
            echo json_encode($response);
        }
        else
        {
            $response = "failed to store";
            echo json_encode($response);
        }       
      
  
 
?>