<?php

include 'db_con.php';
$mobile = $_POST['number'];
// $mobile = '9960210230';


$all_leads = "SELECT * FROM `Doctor_Info` WHERE number='$mobile'";

$result = mysqli_query($conn, $all_leads);
    

while($row = mysqli_fetch_assoc($result))   
{
    
   $datas[] = $row;
 
    
    
    
    
    
    
}

echo json_encode($datas);

?>