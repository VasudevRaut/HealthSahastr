<?php

include 'db_con.php';


$fname = $_POST['firstName'];
$lname = $_POST['lastName'];
$email = $_POST['email'];
$number = $_POST['number'];
$age = $_POST['age'];
$password = $_POST['password'];
$confirmPassword = $_POST['confirmPassword'];
$education = $_POST['education'];
$bio = $_POST['bio'];
$profession = $_POST['profession'];
$charges = $_POST['charges'];
$hospitalName = $_POST['hospitalName'];
$address = $_POST['address'];
$agreed = $_POST['agreed'];
$token = $_POST['token'];
$lati = $_POST['lati'];
$longi = $_POST['longi'];

// $fname = "John";
// $lname = "Doe";
// $email = "johndoeexample.com";
// $number = "12378920";
// $age = "25";
// $password = "password123";
// $confirmPassword = "password123";
// $education = "Bachelors Degree";
// $bio = "Lorem ipsum dolor sit amet consectetur adipiscing elit";
// $profession = "Doctor";
// $charges = "50";
// $hospitalName = "General Hospital";
// $address = "123 Main Street City Country";
// $agreed = "true";
// $token = "abcdef123456";
// $lati = "40.7128"; // Dummy latitude value
// $longi = "-74.0060"; // Dummy longitude value


 



// $user_name = 'Rahul';
// $user_mail = 'rgu';
// $user_contact = '943';
// $user_password = '123';
// $user_bld = 'AB+';
// $user_designation = 'RM';
// $manager = '43656';
// $gender = 'Male';

$select_query = "SELECT * FROM `Doctor_Info` WHERE number = '$number'";

$result = mysqli_query($conn, $select_query);

if ($result) {
    $rows_returned = mysqli_num_rows($result);
        $full_name = $fname. " " .$lname;
    if ($rows_returned > 0) {
        $response['message'] = "already_present";
        echo json_encode($response);
    } else {
        // $insert_query = "INSERT INTO `Doctor_Info`(`name`, `number`, `email`, `pass`, `education`)
        // VALUES ('$full_name','$number','$email','$password','$education')";


         $insert_query = "INSERT INTO `Doctor_Info`(`name`, `number`, `email`, `pass`, `education`, `rating`, `longi`, `lat`, `active_status`, `bio`, `profession`, `charges`, `hospital_name`, `address`, `token`,`type`);
        VALUES ('$full_name','$number','$email','$password','$education','5','$longi','$lati','on','$bio','$profession','$charges','$hospitalName','$address','$token','doctor')";

       

        $isDataUpdated = mysqli_query($conn, $insert_query);

        if ($isDataUpdated) {
            $response['message'] = "success";
            echo json_encode($response);
        } else {
            $response['message'] = "failed to store";
            echo json_encode($response);
        }
    }
}

 
?>