<?php

$host = "localhost";
$user = "u484908010_Health_Shastra";
$pass = "HealthR@123";
$db = "u484908010_Health_Shastra";


$conn = mysqli_connect($host, $user, $pass, $db);

if(!$conn)
{
    $response['message'] = "connection_error";
    echo json_encode($response);
}

?>