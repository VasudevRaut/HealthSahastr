<?php

include 'db_con.php';
$pnumber = $_POST['pnumber'];
$dnumber = $_POST['dnumber'];

$appid = $_POST['appid'];
$device_token = $_POST['token'];
$priciption = $_POST['preciption'];


// $pnumber = "7387579912";
// $dnumber = "123456";

// $appid = "1";
// $device_token = $_POST['token'];
// $priciption = "Vasudevvvvvvvvvvvvvvvvvvvvvvvvvvvv";


     
     
       $insert_query ="UPDATE `Appointment` SET `prescription` = '$priciption' WHERE `patient_number` = '$pnumber' AND doctor_number ='$dnumber' AND app_id ='$appid' ";

        
        $isDataUpdated = mysqli_query($conn, $insert_query);
        
        if($isDataUpdated)
        {
            
            
            
            
            
            
            
            
            
            
            
            
             // FCM API endpoint
                                $apiEndpoint = 'https://fcm.googleapis.com/fcm/send';
                                
                                // Server key or authentication token
                                $serverKey = 'AAAAAf6JLZw:APA91bHt4Vzpp5uW8CW7ceUu5jfgTO9qvu6zn2MHS_UmayEat1N0wqkSfa6zWDJqvMgUjFKVT-myrXBAI4qUpb2x8l9x1OuG2T7CopLjRaCvBhwoFta285wttgajCHkKw6OzdpZ1laBd';
                                
                                
                                $dataPayload = [
                                    'key1' => 'value1',
                                    'key2' => 'value2',
                                ];
                                
                                // Notification payload
                                $notification = [
                                    'title' => 'Received prescription',
                                    'body' => 'Dr. sent you s prescription please check it out',
                                        'click_action' => 'rEMOVE',
                                    'sound' => 'custom_sound',
                                    // Specify an action when the notification is clicked
                                    // 'icon' => 'notification_icon', // Specify the notification icon
                                    // 'data' => [
                                    //     // 'key1' => 'value1', // Additional data to be sent along with the notification
                                    //     // 'key2' => 'value2',
                                    // ],
                                ];
                                
                                // Recipient device token
                                // $deviceToken = 'fJB8DRIJTB-L5UFPWVO5TK:APA91bEsR6uo9nIvq3kxcMrwKiSDTS9NSLd1566ME-uUSHxSwBg9jViCd4qS1QGcdTPYCoL5JNdKuJhwZcpK7jX9kvYXB7ngBAMm4h2nBLX83q0kjrRelFfMB8auZ2pVw8ug0dH6PbZa';
                                
                                $deviceToken = $device_token;
                                
                                // echo $deviceToken;
                                
                                
                                // Prepare the request payload
                                $requestPayload = json_encode([
                                    'to' => $deviceToken,
                                    'notification' => $notification,
                                    'data' => $dataPayload,
                                ]);
                                
                                // Set the request headers
                                $requestHeaders = [
                                    'Authorization: key=' . $serverKey,
                                    'Content-Type: application/json',
                                ];
                                
                                // Initialize cURL and set the request options
                                $curl = curl_init($apiEndpoint);
                                curl_setopt($curl, CURLOPT_POST, true);
                                curl_setopt($curl, CURLOPT_POSTFIELDS, $requestPayload);
                                curl_setopt($curl, CURLOPT_HTTPHEADER, $requestHeaders);
                                curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
                                
                                // Execute the request and capture the response
                                $response = curl_exec($curl);
                                
                                // Check for errors
                                if ($response === false) {
                                    echo 'Error: ' . curl_error($curl);
                                } else {
                                    // Handle the response
                                    echo 'Notification sent successfully: ' . $response;
                                }
                                
                                // Close cURL
                                curl_close($curl);
                                
                                                            
                            
                            
                            
                            
                            
                        // }
                        
                        
                        
                        
                        
                        
                        
                        
                        
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            $response = "success";
            echo json_encode($response);
        }
        else
        {
            $response = "failed to store";
            echo json_encode($response);
        }       
      
  
 
?>